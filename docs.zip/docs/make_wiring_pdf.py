"""Generate Morse Code Locker wiring map PDF."""
from pathlib import Path

try:
    from fpdf import FPDF
except ImportError:
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "fpdf2", "-q"])
    from fpdf import FPDF

OUT = Path(__file__).with_name("Morse-Code-Locker-Wiring-Map.pdf")


class PDF(FPDF):
    def footer(self):
        self.set_y(-12)
        self.set_font("Helvetica", size=8)
        self.set_text_color(100, 100, 100)
        self.cell(
            0,
            8,
            "Morse Code Locker wiring map | Arduino Uno | Common-cathode RGB | I2C OLED on A4/A5",
            align="C",
        )


def section_title(pdf: PDF, text: str):
    pdf.set_font("Helvetica", "B", 13)
    pdf.set_text_color(15, 39, 68)
    pdf.ln(4)
    pdf.cell(0, 8, text, ln=True)
    pdf.set_draw_color(15, 39, 68)
    pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
    pdf.ln(3)


def table(pdf: PDF, headers, rows, col_widths):
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_fill_color(238, 243, 248)
    pdf.set_text_color(15, 39, 68)
    for i, h in enumerate(headers):
        pdf.cell(col_widths[i], 7, h, border=1, fill=True)
    pdf.ln()
    pdf.set_font("Helvetica", size=9.5)
    pdf.set_text_color(26, 26, 26)
    fill = False
    for row in rows:
        pdf.set_fill_color(247, 249, 252)
        for i, cell in enumerate(row):
            pdf.cell(col_widths[i], 6.5, cell, border=1, fill=fill)
        pdf.ln()
        fill = not fill


def main():
    pdf = PDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 18)
    pdf.set_text_color(15, 39, 68)
    pdf.cell(0, 10, "Morse Code Locker - Wiring Map", ln=True)

    pdf.set_font("Helvetica", size=9.5)
    pdf.set_text_color(85, 85, 85)
    pdf.multi_cell(
        0,
        5,
        "Project: mosre-code-locker  |  Board: Arduino Uno  |  "
        "Default password: Morse for AA (.- .-)  |  Generated: 9 Nov 2026",
    )

    section_title(pdf, "1. Uno pins used")
    table(
        pdf,
        ["Uno pin", "Device"],
        [
            ["D2", "Reset / password switch"],
            ["D3", "Morse code button"],
            ["D4", "Clear button"],
            ["D6", "RGB LED - Red"],
            ["D7", "RGB LED - Green"],
            ["D8", "RGB LED - Blue"],
            ["D9", "Buzzer signal"],
            ["D10", "Servo signal"],
            ["A4", "OLED SDA"],
            ["A5", "OLED SCL"],
            ["5V", "OLED, buzzer VCC, servo V+"],
            ["GND", "All grounds (shared)"],
        ],
        [40, 140],
    )

    section_title(pdf, "2. Detail wiring")
    table(
        pdf,
        ["Device", "Device pin", "Uno pin"],
        [
            ["OLED (I2C SSD1306)", "GND", "GND"],
            ["OLED (I2C SSD1306)", "VCC", "5V"],
            ["OLED (I2C SSD1306)", "SDA", "A4"],
            ["OLED (I2C SSD1306)", "SCL", "A5"],
            ["RGB LED (common cathode)", "Common (longest / cathode)", "GND"],
            ["RGB LED (common cathode)", "Red", "220 ohm -> D6"],
            ["RGB LED (common cathode)", "Green", "220 ohm -> D7"],
            ["RGB LED (common cathode)", "Blue", "220 ohm -> D8"],
            ["Buzzer (HW-508)", "-", "GND"],
            ["Buzzer (HW-508)", "middle (+)", "5V"],
            ["Buzzer (HW-508)", "S", "D9"],
            ["Reset / password switch", "One terminal", "D2"],
            ["Reset / password switch", "Other terminal", "GND"],
            ["Morse button", "One side", "D3"],
            ["Morse button", "Other side", "GND"],
            ["Clear button", "One side", "D4"],
            ["Clear button", "Other side", "GND"],
            ["Servo (SG90)", "Brown (GND)", "GND"],
            ["Servo (SG90)", "Red (V+)", "5V"],
            ["Servo (SG90)", "Orange / yellow (signal)", "D10"],
        ],
        [62, 68, 50],
    )

    pdf.ln(4)
    pdf.set_fill_color(247, 249, 252)
    pdf.set_draw_color(15, 39, 68)
    pdf.set_font("Helvetica", size=9)
    pdf.set_text_color(51, 51, 51)
    pdf.multi_cell(
        0,
        5,
        "Notes: Reset switch OFF = lock mode; ON = password reset. "
        "RGB colors: idle yellow, reset blue, correct green, wrong red. "
        "If the Uno resets under servo load, power the servo from a separate 5V supply "
        "and keep GND shared with the Uno.",
        border=1,
        fill=True,
    )

    pdf.output(str(OUT))
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
