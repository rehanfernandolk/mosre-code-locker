# Minimal PDF writer (no third-party deps)
from pathlib import Path

lines = [
    "Morse Code Locker - Wiring Map",
    "Project: mosre-code-locker | Board: Arduino Uno | Default password: AA = .- .- | 9 Nov 2026",
    "",
    "1. Uno pins used",
    "Uno pin | Device",
    "D2 | Reset / password switch",
    "D3 | Morse code button",
    "D4 | Clear button",
    "D6 | RGB LED - Red",
    "D7 | RGB LED - Green",
    "D8 | RGB LED - Blue",
    "D9 | Buzzer signal",
    "D10 | Servo signal",
    "A4 | OLED SDA",
    "A5 | OLED SCL",
    "5V | OLED, buzzer VCC, servo V+",
    "GND | All grounds (shared)",
    "",
    "2. Detail wiring",
    "Device | Device pin | Uno pin",
    "OLED (I2C SSD1306) | GND | GND",
    "OLED (I2C SSD1306) | VCC | 5V",
    "OLED (I2C SSD1306) | SDA | A4",
    "OLED (I2C SSD1306) | SCL | A5",
    "RGB LED (common cathode) | Common (longest / cathode) | GND",
    "RGB LED (common cathode) | Red | 220 ohm -> D6",
    "RGB LED (common cathode) | Green | 220 ohm -> D7",
    "RGB LED (common cathode) | Blue | 220 ohm -> D8",
    "Buzzer (HW-508) | - | GND",
    "Buzzer (HW-508) | middle (+) | 5V",
    "Buzzer (HW-508) | S | D9",
    "Reset / password switch | One terminal | D2",
    "Reset / password switch | Other terminal | GND",
    "Morse button | One side | D3",
    "Morse button | Other side | GND",
    "Clear button | One side | D4",
    "Clear button | Other side | GND",
    "Servo (SG90) | Brown (GND) | GND",
    "Servo (SG90) | Red (V+) | 5V",
    "Servo (SG90) | Orange / yellow (signal) | D10",
    "",
    "Notes: Reset OFF = lock mode; ON = password reset.",
    "RGB: idle yellow, reset blue, correct green, wrong red.",
    "If Uno resets under servo load, use separate 5V for servo with shared GND.",
]


def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


content_lines = ["BT", "/F1 11 Tf", "50 800 Td", "14 TL"]
for i, line in enumerate(lines):
    font = "/F1" if i in (0, 3, 18) else "/F2"
    size = 16 if i == 0 else (12 if i in (3, 18) else 9)
    if i == 0:
        content_lines.append(f"/F1 16 Tf")
    elif i in (3, 18):
        content_lines.append(f"/F1 12 Tf")
    elif i in (1,):
        content_lines.append(f"/F2 8 Tf")
    else:
        content_lines.append(f"/F2 9 Tf")
    content_lines.append(f"({esc(line)}) Tj")
    content_lines.append("T*")
content_lines.append("ET")
stream = "\n".join(content_lines).encode("latin-1", errors="replace")

objects = []
objects.append(b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
objects.append(b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
objects.append(
    b"3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
    b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj\n"
)
objects.append(
    f"4 0 obj\n<< /Length {len(stream)} >>\nstream\n".encode("latin-1")
    + stream
    + b"\nendstream\nendobj\n"
)
objects.append(b"5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n")
objects.append(b"6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n")

out = Path(__file__).with_name("Morse-Code-Locker-Wiring-Map.pdf")
parts = [b"%PDF-1.4\n"]
offsets = [0]
for obj in objects:
    offsets.append(sum(len(p) for p in parts))
    parts.append(obj)
xref_pos = sum(len(p) for p in parts)
xref = [f"xref\n0 {len(objects) + 1}\n", "0000000000 65535 f \n"]
for off in offsets[1:]:
    xref.append(f"{off:010d} 00000 n \n")
parts.append("".join(xref).encode("latin-1"))
parts.append(
    f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n".encode(
        "latin-1"
    )
)
out.write_bytes(b"".join(parts))
print("OK", out, out.stat().st_size)
