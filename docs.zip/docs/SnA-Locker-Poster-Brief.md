# SnA Locker — Full Project Brief (for poster generation)

Use this document as context/prompt input for ChatGPT (or any image/poster tool) to design an **A3 portrait** exhibition side-panel poster.

---

## Poster requirements

- **Size:** A3
- **Orientation:** Portrait
- **Format desired:** PDF / print-ready poster
- **Placement:** Side of exhibition slot
- **Visual style:** Techy, security / access-control vibe
- **Typography:** Matrix-like / monospace / cyber font feel (e.g. Orbitron, Share Tech Mono, VT323-style)
- **Color mood:** Dark background, neon green / cyan accents, amber highlights (terminal / lock-system look)
- **Include:** Product photos of the real build + realistic component images (Arduino Uno, OLED, buzzer, LED, buttons, switch, servo)
- **Tone:** Clever, maker-exhibition, not corporate

---

## Basic info

| Field | Value |
|---|---|
| **Product name** | SnA Locker |
| **SnA means** | Simple and Advanced |
| **Why simple** | There's just a single button |
| **Why advanced** | There's just a single button :) |
| **Done by** | Rehan Fernando (Negombo Branch) |
| **Project / repo name** | mosre-code-locker (Morse code locker) |
| **Board** | Arduino Uno R3 |
| **Default password** | Morse for **AA** → `.- .-` |
| **Concept** | Physical locker unlocked by Morse-code password entered on a button |

### Tagline ideas

- Simple & Advanced
- Morse Access Control
- One button. Full cipher.
- STATUS: SECURE // READY

---

## What the product is

SnA Locker is a DIY electronic locker in a **clear plastic project box**. The user enters a Morse-code password using button press timing (short = dot, long = dash). If the code matches closely enough, a **servo** moves a **metal latch** to unlock. An **OLED** shows prompts and results; an **RGB LED** and **buzzer** give status feedback.

The joke/brand of “Simple and Advanced” is intentional: the UI looks minimal (one main button), but the logic underneath is Morse timing, accuracy scoring, password reset, and servo lock control.

---

## Real product appearance (from photos)

Describe / show these in the poster:

- Clear rectangular plastic enclosure (internals visible — maker aesthetic)
- Metal sliding latch / lock mechanism on the lid
- Micro servo (TowerPro **MG90S** / **SG90** class) linked to the latch
- 0.96" OLED display (shows prompts like `code?`)
- Main black push button for Morse input
- Status LED (RGB in the full design; green visible in some photos)
- Small buzzer
- Arduino Uno inside, powered by USB (blue USB cable)
- Perfboard / prototype board with wiring
- Bundled jumper wires, standoffs, screws
- Side controls on the finished box: power rocker / extra buttons may appear depending on photo

**Photo files available in the project assets (for attaching to ChatGPT):**

- Product with OLED showing `code?`, servo, latch, button
- Side / angle views of clear box with USB and wiring
- Internal build shots
- Hand-drawn UNO wiring sketch
- Printed wiring-map document

---

## Why Simple / Why Advanced (poster copy)

### Why Simple
> there's just a single button

One Morse input control. Short press = `.` (dot). Longer press = `-` (dash). No keypad, no PIN pad — unlock with rhythm.

### Why Advanced
> there's just a single button :)

That same button is a Morse cipher interface: press timing, letter gaps, message end detection, accuracy scoring, password reset flow, RGB state feedback, buzzer tones, and servo-driven physical lock.

---

## How it works (short explainer for poster)

1. OLED prompts for code.
2. User taps Morse on the button (dot/dash by hold time).
3. After a pause (~1.8 s), the system evaluates the Morse string.
4. If accuracy ≥ **75%** vs stored password → **green** LED, success tone, servo unlocks (~90°).
5. If wrong → **red** LED, fail tone, stays locked (~0°).
6. Optional reset switch enters password-change mode (verify old password, then set new).

**Default unlock Morse:** `.- .-` (letter A, letter A)

---

## Component diagram — devices & Uno pins

### Uno pins used

| Uno pin | Device |
|---|---|
| D2 | Reset / password switch |
| D3 | Morse code button |
| D4 | Clear button |
| D6 | RGB LED — Red |
| D7 | RGB LED — Green |
| D8 | RGB LED — Blue |
| D9 | Buzzer signal |
| D10 | Servo signal |
| A4 | OLED SDA |
| A5 | OLED SCL |
| 5V | OLED, buzzer VCC, servo V+ |
| GND | All grounds (shared) |

### Detail wiring

| Device | Device pin | Uno pin |
|---|---|---|
| OLED (I2C SSD1306) | GND | GND |
| OLED (I2C SSD1306) | VCC | 5V |
| OLED (I2C SSD1306) | SDA | A4 |
| OLED (I2C SSD1306) | SCL | A5 |
| RGB LED (common cathode) | Common (longest / cathode) | GND |
| RGB LED (common cathode) | Red | 220 Ω → D6 |
| RGB LED (common cathode) | Green | 220 Ω → D7 |
| RGB LED (common cathode) | Blue | 220 Ω → D8 |
| Buzzer (HW-508) | − | GND |
| Buzzer (HW-508) | middle (+) | 5V |
| Buzzer (HW-508) | S | D9 |
| Reset / password switch | One terminal | D2 |
| Reset / password switch | Other terminal | GND |
| Morse button | One side | D3 |
| Morse button | Other side | GND |
| Clear button | One side | D4 |
| Clear button | Other side | GND |
| Servo (SG90 / MG90S) | Brown (GND) | GND |
| Servo (SG90 / MG90S) | Red (V+) | 5V |
| Servo (SG90 / MG90S) | Orange / yellow (signal) | D10 |

**Ground count:** 7 device grounds → ideally one common GND bus → Uno GND.

---

## Used components with specs

| Component | Specification | Role |
|---|---|---|
| Arduino Uno R3 | ATmega328P · 5V · 16 MHz · USB | Main controller & logic |
| OLED SSD1306 | 0.96" · 128×64 · I2C · address usually 0x3C | Prompt / live Morse / result |
| Micro servo | SG90 or MG90S · PWM on D10 · locked 0° / unlocked 90° | Mechanical latch drive |
| RGB LED | Common cathode · 220 Ω resistors · D6/D7/D8 | Status colors |
| Buzzer module | HW-508 (3-pin: −, +, S) · signal D9 | Dot/dash & result tones |
| Morse button | Momentary push button · D3 ↔ GND | Morse input |
| Clear button | Momentary push button · D4 ↔ GND | Clear current Morse input |
| Reset switch | ON/OFF · D2 ↔ GND | Password reset mode |
| Enclosure | Clear plastic project box | Showcase / exhibition build |
| Latch | Metal sliding latch | Physical lock |

### RGB LED color meanings

| Mode | Color |
|---|---|
| Idle / lock mode | Yellow |
| Password reset mode (switch ON) | Blue |
| Correct password | Green |
| Wrong password | Red |

### Morse timing (firmware)

| Parameter | Value |
|---|---|
| Dot max press | ≤ 250 ms |
| Letter gap | ~700 ms |
| Message end / submit | ~1800 ms idle |
| Unlock threshold | ≥ 75% Morse accuracy |

---

## Speciality (poster bullets)

- Morse-code authentication instead of a numeric keypad
- Single-button UX that hides advanced cipher timing logic
- Accuracy scoring unlock (≥75% match)
- RGB state machine: idle / reset / success / fail
- Password reset flow with old-code verification
- Servo-driven physical lock in a clear showcase box
- OLED live feedback of Morse input and results
- Buzzer audio confirmation for presses and outcomes
- Built as a complete exhibition prototype (box + latch + wiring)

---

## Future enhancements (poster bullets)

- EEPROM password persistence across power loss / Uno reset
- Battery pack or wireless power option (less USB dependence)
- Attempt lockout + audit log on OLED
- Stronger latch / metal-gear servo upgrade for durability
- Optional dual-factor: Morse + hidden switch
- Neater PCB / bus-bar power distribution for production box
- Custom engraved faceplate / branded lid for SnA Locker

---

## Suggested poster layout (A3 portrait)

1. **Header:** SnA LOCKER + “Simple & Advanced” + Done by Rehan Fernando (Negombo Branch)
2. **Hero photo:** Best clear-box product shot
3. **Why Simple / Why Advanced** two panels with the exact witty lines
4. **Component diagram:** Realistic icons of Uno, OLED, RGB LED, buzzer, buttons, switch, servo + pin callouts
5. **Secondary photos:** Internal build + side controls
6. **Specs table:** Components with key specs
7. **Speciality** + **Future enhancements** two columns
8. **Footer:** `SNA LOCKER · MORSE ACCESS · EXHIBITION · A3` and a status line like `STATUS: SECURE // READY`

---

## Suggested ChatGPT prompt (copy/paste)

```text
Create an A3 portrait exhibition poster (print-ready) for a student/maker project called "SnA Locker".

Brand meaning: SnA = Simple and Advanced.
Why simple: there's just a single button
Why advanced: there's just a single button :)
Done by: Rehan Fernando (Negombo Branch)

Visual style: dark tech / security / matrix vibe. Use matrix-like monospace and futuristic display fonts. Neon green and cyan on near-black, amber accents, corner brackets, subtle grid. Feels like an access-control terminal, not a corporate brochure.

Content sections:
1) Title: SnA LOCKER + Simple & Advanced + author line
2) Hero photo of the real clear-box locker prototype (use attached product images)
3) Why Simple / Why Advanced panels with the exact witty lines above
4) Component diagram with realistic images of Arduino Uno, 0.96" I2C OLED, common-cathode RGB LED, HW-508 buzzer, push buttons, ON/OFF reset switch, SG90/MG90S servo, and a metal latch — show Uno pin connections (D2 reset, D3 Morse, D4 clear, D6/D7/D8 RGB, D9 buzzer, D10 servo, A4/A5 OLED)
5) Used components table with specs
6) Speciality bullets (Morse authentication, accuracy unlock, RGB states, password reset, servo lock, clear showcase box)
7) Future enhancements bullets (EEPROM password save, battery power, lockout/audit log, stronger latch, dual-factor)
8) Footer: SNA LOCKER · MORSE ACCESS · STATUS: SECURE // READY

Product concept: Morse-code password locker. Short button press = dot, long press = dash. Default password AA = .- .- . Correct = green + unlock servo; wrong = red + stay locked.

Use the attached photos of the finished clear enclosure prototype. Keep text readable from a short distance. Portrait A3 composition, balanced, exhibition side-panel quality.
```

---

## Related project docs already in repo

- `docs/SnA-Locker-Exhibition-Poster.pdf` — existing generated poster attempt
- `docs/poster/SnA-Locker-Exhibition-Poster.html` — HTML source for that poster
- `docs/Morse-Code-Locker-Wiring-Map.pdf` — wiring map
- `docs/Morse-Code-Locker-Parts-List.pdf` — parts list with HAVE/NEED notes

---

## Notes / caveats for accurate poster text

- Exhibition branding emphasizes **single-button** simplicity; the firmware also supports Clear (D4) and Reset switch (D2). Poster can focus on the single Morse button as the hero UX, and list other controls under components.
- Password changed via reset switch is stored in RAM only unless EEPROM enhancement is added — power cycle returns to default AA unless enhanced.
- OLED must be **I2C 4-pin** (not 7-pin SPI) for this firmware.
- RGB LED must be **common cathode** for the current HIGH=on logic.
- Servo may need a separate 5V supply in some builds; GND must stay shared with Uno.
