const fs = require("fs");
const { execFileSync } = require("child_process");
const path = require("path");

const out = path.join(__dirname, "..", "SnA-Locker-Exhibition-Poster.pdf");
const html = "file:///D:/RAY/mosre-code-locker/docs/poster/SnA-Locker-Exhibition-Poster.html";
const browsers = [
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
];
const browser = browsers.find((p) => fs.existsSync(p));
const log = [];
log.push("browser=" + browser);
if (!browser) {
  fs.writeFileSync(path.join(__dirname, "node_status.txt"), log.join("\n"));
  process.exit(1);
}
try {
  execFileSync(
    browser,
    [
      "--headless",
      "--disable-gpu",
      "--no-pdf-header-footer",
      "--allow-file-access-from-files",
      "--print-to-pdf=" + out,
      html,
    ],
    { timeout: 90000, stdio: "pipe" }
  );
} catch (e) {
  log.push("error=" + e.message);
}
log.push("exists=" + fs.existsSync(out));
if (fs.existsSync(out)) log.push("size=" + fs.statSync(out).size);
fs.writeFileSync(path.join(__dirname, "node_status.txt"), log.join("\n"));
