import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTML = ROOT / "SnA-Locker-Exhibition-Poster.html"
OUT = ROOT.parent / "SnA-Locker-Exhibition-Poster.pdf"
LOG = ROOT / "export_log.txt"

chrome_candidates = [
    Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
]

lines = []
browser = next((p for p in chrome_candidates if p.exists()), None)
lines.append(f"browser={browser}")
lines.append(f"html_exists={HTML.exists()}")
lines.append(f"html={HTML}")
lines.append(f"out={OUT}")

if not browser:
    LOG.write_text("\n".join(lines + ["NO_BROWSER"]), encoding="utf-8")
    sys.exit(1)

# Prefer Edge if Chrome headless is flaky on this machine
edge = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
edge64 = Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe")
if edge64.exists():
    browser = edge64
elif edge.exists():
    browser = edge

cmd = [
    str(browser),
    "--headless=new",
    "--disable-gpu",
    "--no-pdf-header-footer",
    "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw",
    "--virtual-time-budget=20000",
    f"--print-to-pdf={OUT}",
    HTML.as_uri(),
]
lines.append("CMD " + " ".join(cmd))
try:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
    lines.append(f"returncode={proc.returncode}")
    lines.append("stdout=" + (proc.stdout or "")[:800])
    lines.append("stderr=" + (proc.stderr or "")[:800])
except Exception as exc:
    lines.append(f"EXCEPTION={exc!r}")
    LOG.write_text("\n".join(lines), encoding="utf-8")
    sys.exit(2)

lines.append(f"out_exists={OUT.exists()}")
if OUT.exists():
    lines.append(f"out_size={OUT.stat().st_size}")
LOG.write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
sys.exit(0 if OUT.exists() else 3)
