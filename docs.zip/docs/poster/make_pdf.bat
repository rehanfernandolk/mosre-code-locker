@echo off
set EDGE64="C:\Program Files\Microsoft\Edge\Application\msedge.exe"
set EDGE86="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
set CHROME="C:\Program Files\Google\Chrome\Application\chrome.exe"
set OUT=D:\RAY\mosre-code-locker\docs\SnA-Locker-Exhibition-Poster.pdf
set HTML=file:///D:/RAY/mosre-code-locker/docs/poster/SnA-Locker-Exhibition-Poster.html
set LOG=D:\RAY\mosre-code-locker\docs\poster\bat_log.txt

echo start > "%LOG%"
if exist %EDGE64% (
  echo using edge64 >> "%LOG%"
  %EDGE64% --headless=new --disable-gpu --no-pdf-header-footer --allow-file-access-from-files --virtual-time-budget=30000 --print-to-pdf="%OUT%" "%HTML%" >> "%LOG%" 2>&1
) else if exist %EDGE86% (
  echo using edge86 >> "%LOG%"
  %EDGE86% --headless=new --disable-gpu --no-pdf-header-footer --allow-file-access-from-files --virtual-time-budget=30000 --print-to-pdf="%OUT%" "%HTML%" >> "%LOG%" 2>&1
) else (
  echo using chrome >> "%LOG%"
  %CHROME% --headless=new --disable-gpu --no-pdf-header-footer --allow-file-access-from-files --virtual-time-budget=30000 --print-to-pdf="%OUT%" "%HTML%" >> "%LOG%" 2>&1
)
if exist "%OUT%" (
  echo SUCCESS >> "%LOG%"
) else (
  echo FAIL >> "%LOG%"
)
